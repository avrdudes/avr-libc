var searchData=
[
  ['vfprintf_0',['vfprintf',['../group__avr__stdio.html#gaa3b98c0d17b35642c0f3e4649092b9f1',1,'stdio.h']]],
  ['vfprintf_5ff_1',['vfprintf_F',['../group__avr__flash.html#ga7bcb371c72e6c4bdd1f1f60e051f3dec',1,'flash.h']]],
  ['vfprintf_5fp_2',['vfprintf_P',['../group__avr__stdio.html#ga55b25ecbfd3811ea4495d1f235e2e186',1,'vfprintf_P(FILE *__stream, const char *__fmt, va_list __ap):&#160;vfprintf_p.c'],['../group__avr__stdio.html#ga55b25ecbfd3811ea4495d1f235e2e186',1,'vfprintf_P(FILE *stream, const char *fmt, va_list ap):&#160;vfprintf_p.c']]],
  ['vfscanf_3',['vfscanf',['../group__avr__stdio.html#ga67bae1ad3af79809fd770be392f90e21',1,'vfscanf(FILE *__stream, const char *__fmt, va_list __ap):&#160;vfscanf.c'],['../group__avr__stdio.html#ga67bae1ad3af79809fd770be392f90e21',1,'vfscanf(FILE *stream, const char *fmt, va_list ap):&#160;vfscanf.c']]],
  ['vfscanf_5ff_4',['vfscanf_F',['../group__avr__flash.html#ga1c0659168754e7dedc7f9f4519b4ba6c',1,'flash.h']]],
  ['vfscanf_5fp_5',['vfscanf_P',['../group__avr__stdio.html#ga6c6b5b881ce8f4739777ff3a615e988a',1,'vfscanf_P(FILE *__stream, const char *__fmt, va_list __ap):&#160;vfscanf_p.c'],['../group__avr__stdio.html#ga6c6b5b881ce8f4739777ff3a615e988a',1,'vfscanf_P(FILE *stream, const char *fmt, va_list ap):&#160;vfscanf_p.c']]],
  ['vprintf_6',['vprintf',['../group__avr__stdio.html#ga0b15be24dd9db93355e1f62937fdfd9a',1,'vprintf(const char *__fmt, va_list __ap):&#160;vprintf.c'],['../group__avr__stdio.html#ga0b15be24dd9db93355e1f62937fdfd9a',1,'vprintf(const char *fmt, va_list ap):&#160;vprintf.c']]],
  ['vscanf_7',['vscanf',['../group__avr__stdio.html#ga8bd4b760f67791a54e73111734caa82f',1,'vscanf(const char *__fmt, va_list __ap):&#160;vscanf.c'],['../group__avr__stdio.html#ga8bd4b760f67791a54e73111734caa82f',1,'vscanf(const char *fmt, va_list ap):&#160;vscanf.c']]],
  ['vsnprintf_8',['vsnprintf',['../group__avr__stdio.html#ga1797e15713c635606cbaf6ba56e98fe5',1,'vsnprintf(char *__s, size_t __n, const char *__fmt, va_list __ap):&#160;vsnprintf.c'],['../group__avr__stdio.html#ga1797e15713c635606cbaf6ba56e98fe5',1,'vsnprintf(char *s, size_t n, const char *fmt, va_list ap):&#160;vsnprintf.c']]],
  ['vsnprintf_5ff_9',['vsnprintf_F',['../group__avr__flash.html#ga700536c6a64d8b8cdac2dedeaa5a0105',1,'flash.h']]],
  ['vsnprintf_5fp_10',['vsnprintf_P',['../group__avr__stdio.html#gac0902d91baba413dedb08474f2ae4383',1,'vsnprintf_P(char *__s, size_t __n, const char *__fmt, va_list __ap):&#160;vsnprintf_p.c'],['../group__avr__stdio.html#gac0902d91baba413dedb08474f2ae4383',1,'vsnprintf_P(char *s, size_t n, const char *fmt, va_list ap):&#160;vsnprintf_p.c']]],
  ['vsprintf_11',['vsprintf',['../group__avr__stdio.html#ga129a84920638c8e538e80fdeb6d69a6f',1,'vsprintf(char *__s, const char *__fmt, va_list __ap):&#160;vsprintf.c'],['../group__avr__stdio.html#ga129a84920638c8e538e80fdeb6d69a6f',1,'vsprintf(char *s, const char *fmt, va_list ap):&#160;vsprintf.c']]],
  ['vsprintf_5ff_12',['vsprintf_F',['../group__avr__flash.html#gafcf2617ae3689c12c6495b600561a5f9',1,'flash.h']]],
  ['vsprintf_5fp_13',['vsprintf_P',['../group__avr__stdio.html#gab5cb9ba918b3c3f80399e1164a8b28d2',1,'vsprintf_P(char *__s, const char *__fmt, va_list __ap):&#160;vsprintf_p.c'],['../group__avr__stdio.html#gab5cb9ba918b3c3f80399e1164a8b28d2',1,'vsprintf_P(char *s, const char *fmt, va_list ap):&#160;vsprintf_p.c']]]
];
